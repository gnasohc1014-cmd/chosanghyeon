$(function(){
    $(".slider").slick({
        autoplay: true,
        infinity:true,
        slidesToShow: 3,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 769,
                settings:{
                    slidesToShow: 2,
                    slidesToScroll: 2,
                }
            },
            {
                breakpoint: 480, 
                settings: {
                    slidesToShow:1,
                    slidesToScroll: 1,
                }
            }
        ]
    });
    $(".slick-buttons a").on("click", function(e){
        e.preventDefault();
        
        $(".slick-buttons a").removeClass("active");
        $(this).addClass("active");
        
        const className = $(this).attr("class").split(" ")[0];
        
        if (className === "all") {
            $(".slider").slick("slickUnfilter");
        } else if (className === "aaa") {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".aaa"));
        } else if (className === "bbb") {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".bbb"));
        } else if (className === "ccc") {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".ccc"));
        } else if (className === "ddd") {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".ddd"));
        }
        
        // 슬라이드를 첫 번째로 이동
        $(".slider").slick("slickGoTo", 0, false);
    });
});