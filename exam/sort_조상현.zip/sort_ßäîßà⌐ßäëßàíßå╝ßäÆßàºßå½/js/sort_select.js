$(function(){
    $("select").on("change", function(){
        const ab = $(this).val();           // case1, case2
        const n = ab.substr(4,1);           // 1 또는 2
        const $lis = $("#content ul li");   // 상품 목록

        const sort = $lis.sort(function(a,b){
            const priceA = parseInt($(a).find("span.price").text().replace(/[^0-9]/g,''), 10);
            const priceB = parseInt($(b).find("span.price").text().replace(/[^0-9]/g,''), 10);

            if(n == 1){
                // 높은 가격순 (내림차순)
                return priceB - priceA;
            }else if(n == 2){
                // 낮은 가격순 (오름차순)
                return priceA - priceB;
            }
        });

        $("#content ul").html(sort); // 정렬된 결과 반영
    });
});
