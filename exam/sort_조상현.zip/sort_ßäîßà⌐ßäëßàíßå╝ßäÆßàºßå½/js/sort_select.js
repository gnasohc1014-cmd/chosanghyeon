$(function(){
    $("select").on("change", function(){
        const ab = $(this).val();          
        const n = ab.substr(4,1);          
        const $lis = $("#content ul li");  

        const sort = $lis.sort(function(a,b){
            if(n == 0){
                location.reload(true);
            }else if(n == 1){
                return parseInt($(a).find("span.price").text().replace(/[^0-9]/g,'')) >
                       parseInt($(b).find("span.price").text().replace(/[^0-9]/g,'')) ? -1 :
                       parseInt($(a).find("span.price").text().replace(/[^0-9]/g,'')) <
                       parseInt($(b).find("span.price").text().replace(/[^0-9]/g,'')) ? 1 : 0;
            }else{
                return parseInt($(a).find("span.price").text().replace(/[^0-9]/g,'')) <
                       parseInt($(b).find("span.price").text().replace(/[^0-9]/g,'')) ? -1 :
                       parseInt($(a).find("span.price").text().replace(/[^0-9]/g,'')) >
                       parseInt($(b).find("span.price").text().replace(/[^0-9]/g,'')) ? 1 : 0;
            }
        });

        $("#content ul").html(sort); 
    });
});