$(function(){
    $("#search ul li").on("click", function(){
        const type = $(this).attr("class");

        const items = $("#content ul li").get();

        items.sort(function(a, b){
            const priceA = parseInt($(a).find("span.price").text().replace(/[^0-9]/g, ""), 10);
            const priceB = parseInt($(b).find("span.price").text().replace(/[^0-9]/g, ""), 10);

            if(type === "case1"){ 
                return priceB - priceA;
            }else if(type === "case2"){ 
                return priceA - priceB;
            }else{
                return 0; 
            }
        });
        $("#content ul").empty().append(items);
    });
});
