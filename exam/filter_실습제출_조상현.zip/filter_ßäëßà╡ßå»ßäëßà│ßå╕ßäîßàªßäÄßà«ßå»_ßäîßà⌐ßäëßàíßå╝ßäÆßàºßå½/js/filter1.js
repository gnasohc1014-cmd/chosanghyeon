$(function(){
    const tagged = {};
    $("#gallery img").each(function(){
        const img = this;
        const tags = $(this).data('tags');
        if(tags){
            tags.split(',').forEach(function(tagName){
                tagName = tagName.trim();
                if (tagged[tagName] == null) {
                    tagged[tagName] = [];
                }
                tagged[tagName].push(img);
            });
        }
    });

    $(".first a").on("click", function(e){
        e.preventDefault();
        $("#button li").removeClass('active');
        $(this).addClass('active');
        $("#gallery img").show();
    });

    $("#button li").on("click", function(){
        $(".first a").removeClass('active');
        $(this)
            .addClass('active')
            .siblings()
            .removeClass('active');
        const tagName = $(this).text().toLowerCase().trim();
        $("#gallery img").hide();
        if(tagged[tagName]){
            $(tagged[tagName]).show();
        }
    });
});
