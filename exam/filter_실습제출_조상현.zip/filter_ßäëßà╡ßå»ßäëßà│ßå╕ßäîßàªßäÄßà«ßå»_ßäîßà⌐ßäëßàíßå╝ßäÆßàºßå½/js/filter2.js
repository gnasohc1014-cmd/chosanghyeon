const cache = [];

function filter() {
    if (cache.length === 0) {
        $('#gallery img').each(function() {
            const alt = (this.alt ? this.alt : '').toLowerCase();
            const tags = ($(this).attr('data-tags') ? $(this).attr('data-tags') : '').toLowerCase();
            const keywords = (alt + ',' + tags)
                .split(',')
                .map(s => s.trim())
                .filter(s => s.length > 0);
            cache.push({
                element: this,
                keywords: keywords
            });
        });
    }

    const x = document.getElementById("filter-search").value;
    const query = x.trim().toLowerCase();

    cache.forEach(function(img) {
        if (!query) {
            img.element.style.display = '';
            return;
        }
        const matched = img.keywords.some(function(word) {
            return word.startsWith(query);
        });
        img.element.style.display = matched ? '' : 'none';
    });
}

