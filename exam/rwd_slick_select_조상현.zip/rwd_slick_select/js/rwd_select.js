$(function(){
    $(".slider").slick({
        autoplay: true,
        infinity:true,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 769,
                settings:{
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480, 
                settings: {
                    slidesToShow:1,
                    slidesToScroll: 1,
                }
            }
        ]
    });
    $("select.test").on("change", function(e){
        const selectedValue = $(this).val();
        
        const slideTo = selectedValue.replace('sel', '');
        
        if (slideTo == 0){
            $(".slider").slick("slickUnfilter");
        }else if(slideTo == 1){
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".aaa"));
        }else if(slideTo == 2){
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".bbb"));
        }else if(slideTo == 3){
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".ccc"));
        }else if(slideTo == 4){
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter", $(".slider li").filter(".ddd"));
        }
        
        $(".slider").slick("slickGoTo", 0, false);
    });
});