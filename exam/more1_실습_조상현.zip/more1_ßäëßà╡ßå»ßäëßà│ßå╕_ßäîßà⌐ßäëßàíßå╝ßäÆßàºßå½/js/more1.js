$(function(){
function listMore(){
    const $items = $('#arsenal_shop li');
    const totalItems = $items.length;
    let showCount = 0;

    const winWidth = $(window).width();
    if(winWidth <= 640){
        $items.css('width','50%')
        showCount = 2;
    }else if (winWidth <= 768){
        $items.css('width','33.33%')
        showCount = 3;
    }else{
        $items.css('width','25%')
        showCount = 4;
    }

    $items.hide();
    $items.slice(0, showCount).show();

    $('.more_btn').off('click').on('click', function(){
        let visibleCount = $('#arsenal_shop li:visible').length;
        let nextCount = visibleCount + showCount;
        if(nextCount > totalItems) nextCount = totalItems;

        $items.slice(0, nextCount).show();
        if(nextCount === totalItems){
            $('.more_btn').hide();
        }
    });

        if(showCount < totalItems){
        $('.more_btn').show();
    }else{
        $('.more_btn').hide();
    }
}   
    listMore()

//창 크기 변경 시 다시 적용
    $(window).on('resize',function(){
        listMore();

    })
});